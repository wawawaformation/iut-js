function genererNombreAleatoire() {
    return Math.floor(Math.random() * 101);
}
